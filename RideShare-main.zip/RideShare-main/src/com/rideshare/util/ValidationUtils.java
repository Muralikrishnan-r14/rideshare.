package com.rideshare.util;

// Core reusable validation helpers
public class ValidationUtils {

    public static boolean isBlank(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            System.out.println("Error: " + fieldName + " cannot be empty!");
            return true;
        }
        return false;
    }

    public static boolean matchesPattern(String value, String regex, String errorMsg) {
        if (!value.matches(regex)) {
            System.out.println("Error: " + errorMsg);
            return false;
        }
        return true;
    }

    public static boolean hasMinLength(String value, int min, String fieldName) {
        if (value.trim().length() < min) {
            System.out.println("Error: " + fieldName + " must be at least " + min + " characters!");
            return false;
        }
        return true;
    }

    // Combines blank + pattern + minLength check in one call
    public static boolean validateField(String value, String fieldName, String regex, String regexMsg, int minLen) {
        if (isBlank(value, fieldName)) return false;
        if (!hasMinLength(value, minLen, fieldName)) return false;
        return matchesPattern(value, regex, regexMsg);
    }
}
