package com.rideshare.util;

// Validates driver-specific fields: license, vehicle make/model, seats
public class DriverValidator {

    private static final String LETTERS_ONLY = "[a-zA-Z ]+";
    private static final String ALPHANUMERIC = "[a-zA-Z0-9 ]+";
    private static final String LICENSE_REGEX = "(?i)li[0-9]{7}";

    public static boolean isValidLicenseNumber(String license) {
        if (ValidationUtils.isBlank(license, "License number")) return false;
        return ValidationUtils.matchesPattern(license, LICENSE_REGEX,
                "License number must start with 'li' followed by exactly 7 digits! (e.g., li1234567)");
    }

    public static boolean isValidVehicleMake(String make) {
        return ValidationUtils.validateField(make, "Vehicle make", LETTERS_ONLY,
                "Vehicle make must contain only letters and spaces!", 2);
    }

    public static boolean isValidVehicleModel(String model) {
        if (ValidationUtils.isBlank(model, "Vehicle model")) return false;
        return ValidationUtils.matchesPattern(model, ALPHANUMERIC,
                "Vehicle model must contain only letters, digits, and spaces!");
    }

    public static boolean isValidSeats(int seats) {
        if (seats < 1 || seats > 10) {
            System.out.println("Error: Available seats must be between 1 and 10!");
            return false;
        }
        return true;
    }
}
