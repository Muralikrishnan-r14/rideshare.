package com.rideshare.service;

import java.util.Scanner;

import com.rideshare.repository.Database;
import com.rideshare.model.Passenger;
import com.rideshare.model.Ride;
import com.rideshare.model.Booking;
import com.rideshare.model.Rating;
import com.rideshare.util.IdGenerator;
import com.rideshare.util.UserValidator;
import com.rideshare.util.DuplicateChecker;

public class PassengerService {

    static Scanner sc = new Scanner(System.in);

    public static void registerPassenger() {

        System.out.println("\n===== PASSENGER REGISTRATION =====");

        System.out.print("Enter Name: ");
        String name = sc.nextLine();

        if (!UserValidator.isValidName(name)) return;

        System.out.print("Enter Email: ");
        String email = sc.nextLine();

        if (!UserValidator.isValidEmail(email)) return;
        if (DuplicateChecker.isDuplicatePassengerEmail(email)) return;

        System.out.print("Enter Password: ");
        String password = sc.nextLine();

        if (!UserValidator.isValidPassword(password)) return;

        System.out.print("Enter Mobile: ");
        String mobileStr = sc.nextLine();

        if (!UserValidator.isValidMobile(mobileStr)) return;

        long mobile = Long.parseLong(mobileStr);

        System.out.print("Enter City: ");
        String city = sc.nextLine();

        if (!UserValidator.isValidCity(city)) return;

        int passengerId = IdGenerator.generatePassengerId();

        Passenger passenger = new Passenger(
                passengerId,
                name,
                email,
                password,
                mobile,
                city,
                "ACTIVE"
        );

        Database.passengers.add(passenger);

        System.out.println("\nPassenger Registered Successfully!");
        System.out.println("Passenger ID: " + passengerId);
    }

    public static void browseRides() {

        boolean found = false;

        System.out.println("\n===== AVAILABLE RIDES =====");

        for (Ride ride : Database.rides) {

            if (ride.getRegistrationStatus().equals("APPROVED")
                    && ride.getRideStatus().equals("ACTIVE")) {

                found = true;

                System.out.println(ride);
            }
        }

        if (!found) {

            System.out.println("No Rides Available");
        }
    }

    public static void bookRide(Passenger passenger) {

        browseRides();

        System.out.print("\nEnter Ride ID to Book: ");
        int rideId = sc.nextInt();

        System.out.print("Enter Number of Seats: ");
        int seats = sc.nextInt();
        sc.nextLine();

        for (Ride ride : Database.rides) {

            if (ride.getRideId() == rideId
                    && ride.getRegistrationStatus().equals("APPROVED")
                    && ride.getRideStatus().equals("ACTIVE")) {

                int bookingId = IdGenerator.generateBookingId();

                Booking booking = new Booking(
                        bookingId,
                        rideId,
                        passenger.getPassengerId(),
                        seats,
                        "BOOKED"
                );

                Database.bookings.add(booking);

                System.out.println("\nRide Booked Successfully!");
                System.out.println("Booking ID: " + bookingId);

                return;
            }
        }

        System.out.println("Invalid Ride ID!");
    }

    public static void viewBookingHistory(Passenger passenger) {

        boolean found = false;

        System.out.println("\n===== BOOKING HISTORY =====");

        for (Booking booking : Database.bookings) {

            if (booking.getPassengerId() == passenger.getPassengerId()) {

                found = true;

                System.out.println(booking);
            }
        }

        if (!found) {

            System.out.println("No Bookings Found!");
        }
    }

    public static void rateDriver(Passenger passenger) {

        viewBookingHistory(passenger);

        System.out.print("\nEnter Ride ID to Rate: ");
        int rideId = sc.nextInt();

        double driverId = -1;

        for (Ride ride : Database.rides) {

            if (ride.getRideId() == rideId) {

                driverId = ride.getDriverId();
                break;
            }
        }

        if (driverId == -1) {

            System.out.println("Invalid Ride ID!");
            return;
        }

        System.out.print("Enter Rating (1 to 5): ");
        double ratingValue = sc.nextDouble();
        sc.nextLine();

        if (ratingValue < 1 || ratingValue > 5) {

            System.out.println("Invalid Rating!");
            return;
        }

        int ratingId = IdGenerator.generateRatingId();

        Rating rating = new Rating(
                ratingId,
                (int) driverId,
                passenger.getPassengerId(),
                ratingValue
        );

        Database.ratings.add(rating);

        System.out.println("Driver Rated Successfully!");
    }

    public static void viewPassengers() {

        if (Database.passengers.isEmpty()) {

            System.out.println("\nNo Passengers Found!");
            return;
        }

        System.out.println("\n===== PASSENGER DETAILS =====");

        for (Passenger passenger : Database.passengers) {

            System.out.println(passenger);
            System.out.println("--------------------------");
        }
    }

    public static void updateProfile(Passenger passenger) {

        System.out.println("\n===== UPDATE PASSENGER PROFILE =====");

        System.out.print("New Name: ");
        String name = sc.nextLine();

        if (!UserValidator.isValidName(name)) return;

        System.out.print("New Email: ");
        String email = sc.nextLine();

        if (!UserValidator.isValidEmail(email)) return;

        // Check duplicate only if email actually changed
        if (!email.equalsIgnoreCase(passenger.getEmail())
                && DuplicateChecker.isDuplicatePassengerEmail(email)) return;

        System.out.print("New Password: ");
        String password = sc.nextLine();

        if (!UserValidator.isValidPassword(password)) return;

        System.out.print("New Mobile Number: ");
        String mobileStr = sc.nextLine();

        if (!UserValidator.isValidMobile(mobileStr)) return;

        long mobile = Long.parseLong(mobileStr);

        System.out.print("New City: ");
        String city = sc.nextLine();

        if (!UserValidator.isValidCity(city)) return;

        passenger.setPassengerName(name);
        passenger.setEmail(email);
        passenger.setPassword(password);
        passenger.setMobile(mobile);
        passenger.setCity(city);

        System.out.println("\nProfile Updated Successfully!");
    }

    public static boolean deactivateAccount(Passenger passenger) {

        System.out.print("\nAre you sure? (Y/N): ");

        String choice = sc.nextLine();

        if (choice.equalsIgnoreCase("Y")) {

            passenger.setRegistrationStatus("INACTIVE");

            System.out.println("Account Deactivated Successfully!");

            return true;
        }

        System.out.println("Operation Cancelled!");

        return false;
    }
}
