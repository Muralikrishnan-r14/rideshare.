package com.rideshare.repository;

import java.util.ArrayList;

import com.rideshare.model.Driver;
import com.rideshare.model.Passenger;
import com.rideshare.model.Ride;
import com.rideshare.model.Booking;
import com.rideshare.model.Rating;
import com.rideshare.model.AuditLog;

public class Database {

    public static ArrayList<Driver> drivers = new ArrayList<>();

    public static ArrayList<Passenger> passengers = new ArrayList<>();

    public static ArrayList<Ride> rides = new ArrayList<>();

    public static ArrayList<Booking> bookings = new ArrayList<>();

    public static ArrayList<Rating> ratings = new ArrayList<>();

    public static ArrayList<AuditLog> auditLogs = new ArrayList<>();

    public static void addAuditLog(AuditLog log) {
        auditLogs.add(log);
    }

}
